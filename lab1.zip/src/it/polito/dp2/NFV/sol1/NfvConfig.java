package it.polito.dp2.NFV.sol1;

public class NfvConfig {
	public static final String schemaFile = "xsd/nfvInfo.xsd";
	public static final String inputFileProperty = "it.polito.dp2.NFV.sol1.NfvInfo.file";
	public static final String jaxbClassesPackage = "it.polito.dp2.NFV.sol1.jaxb";
	
	private NfvConfig() {
	}
}